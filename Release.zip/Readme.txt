
1. DNNWordCount_00.00.01_Install is the Extension Package.

2. The EntityFramework, EntityFramework.SqlServer and HtmlAgilityPack dlls are required by the services, so should be copied to the bin folder.

3. A new connection string should be added to the web.config of the DNN site -> without a valid connection string, search history will not persist.